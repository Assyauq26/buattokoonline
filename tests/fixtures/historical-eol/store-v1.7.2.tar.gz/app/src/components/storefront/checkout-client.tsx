"use client";

import { useFormState, useFormStatus } from "react-dom";
import { useEffect, useRef, useState } from "react";
import { Truck, CreditCard, Ticket, Info } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input, Label, Textarea } from "@/components/ui/input";
import { RegionSelectorDialog } from "./region-selector-dialog";
import {
  addressSchema,
  jntLocationSchema,
  locationSchema,
  type SelectedLocation,
} from "@/modules/regions/region.validation";
import { formatIDR } from "@/lib/money";
import { createOrderAction } from "@/modules/checkout/checkout.actions";
import type { CheckoutLines } from "@/modules/checkout/checkout.validation";
import { cn } from "@/lib/utils";

interface Rate {
  courier: string;
  service: string;
  cost: number;
  etd?: string;
  quoteToken: string;
  expiresAt: number;
  mode: "manual" | "official";
}
interface Bank {
  id: string;
  displayName: string;
  bankName: string;
  accountNumber: string;
  accountHolder: string;
}
interface Addr {
  recipientName: string;
  phone: string;
  line: string;
  city: string;
  province: string;
  postalCode: string;
  provinceCode?: string | null;
  cityCode?: string | null;
  districtCode?: string | null;
  villageCode?: string | null;
  district?: string | null;
  village?: string | null;
  regionSource?: string | null;
  regionUpdatedAt?: string | null;
}
interface CheckoutQuote {
  subtotal: number;
  shippingCost: number;
  discount: number;
  total: number;
  couponCode: string | null;
  couponReason: string | null;
  shippingRates: Rate[];
  shippingValid: boolean;
  quoteExpiresAt: number | null;
}
type QuoteState =
  | { key: string; status: "loading" }
  | { key: string; status: "error"; message: string }
  | { key: string; status: "ready"; data: CheckoutQuote };

function PlaceOrderBtn({ disabled }: { disabled: boolean }) {
  const { pending } = useFormStatus();
  return (
    <Button
      type="submit"
      className="checkout-submit w-full"
      size="lg"
      disabled={pending || disabled}
      data-testid="place-order-btn"
    >
      {pending ? "Memproses..." : "Buat Pesanan"}
    </Button>
  );
}

export function CheckoutClient({
  subtotal,
  expectedLines,
  requestId,
  intentId,
  banks,
  address,
  jntCheckout = false,
}: {
  subtotal: number;
  expectedLines: CheckoutLines;
  requestId: string;
  intentId?: string;
  banks: Bank[];
  address: Addr | null;
  jntCheckout?: boolean;
}) {
  const [state, action] = useFormState(createOrderAction, { ok: false } as any);
  const submitting = useRef(false);
  useEffect(() => {
    submitting.current = false;
  }, [state]);
  const [rates, setRates] = useState<Rate[]>([]);
  const [rateIdx, setRateIdx] = useState(-1);
  const [location, setLocation] = useState<SelectedLocation | null>(() => {
    if (!address?.district) return null;
    const schema = jntCheckout ? jntLocationSchema : locationSchema;
    const parsed = schema.safeParse({
      ...address,
      villageCode: jntCheckout
        ? (address.villageCode ?? "")
        : address.villageCode,
    });
    if (!parsed.success || !address.village) return null;
    return {
      ...address,
      ...parsed.data,
      district: address.district,
      village: address.village ?? "",
      regionSource: jntCheckout ? "jnt-mapping" : "emsifa-v2",
      regionUpdatedAt: address.regionUpdatedAt || "",
    };
  });
  const [recipient, setRecipient] = useState(address?.recipientName || "");
  const [phone, setPhone] = useState(address?.phone || "");
  const [street, setStreet] = useState(address?.line || "");
  const [now, setNow] = useState(0);
  const [bankId, setBankId] = useState(banks[0]?.id ?? "");
  const [couponCode, setCouponCode] = useState("");
  const [couponDraft, setCouponDraft] = useState("");
  const [retry, setRetry] = useState(0);
  const [quote, setQuote] = useState<QuoteState | null>(null);
  const shippingKey = JSON.stringify([intentId, expectedLines, location]);
  const [rateContext, setRateContext] = useState("");
  const [shippingNotice, setShippingNotice] = useState("");
  const wanted = useRef<Rate>();
  const ratesValid = rateContext === shippingKey;
  const rate = ratesValid ? rates[rateIdx] : undefined;
  const quoteKey = JSON.stringify([
    intentId,
    couponCode,
    rate?.courier,
    rate?.service,
    rate?.cost,
    rate?.quoteToken,
    shippingKey,
    retry,
  ]);

  useEffect(() => {
    if (!location) {
      setQuote({
        key: quoteKey,
        status: "error",
        message: "Silakan pilih lokasi pengiriman.",
      });
      return;
    }
    let active = true;
    const controller = new AbortController();
    setQuote({ key: quoteKey, status: "loading" });
    // Debounce typing; clearing a coupon / changing a rate can refresh immediately.
    const timeout = setTimeout(
      async () => {
        try {
          const response = await fetch("/api/v1/checkout/preview", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            credentials: "same-origin",
            cache: "no-store",
            signal: controller.signal,
            body: JSON.stringify({
              intentId,
              couponCode: couponCode || undefined,
              address: location,
              shipping: rate
                ? {
                    courier: rate.courier,
                    service: rate.service,
                    cost: rate.cost,
                    quoteToken: rate.quoteToken,
                  }
                : undefined,
            }),
          });
          const result = await response.json();
          if (!response.ok || result.success !== true) {
            if (active && rate && [409, 422].includes(response.status)) {
              wanted.current = rate;
              setRateContext("");
              setRetry((n) => n + 1);
              setShippingNotice(
                "Tarif sedang divalidasi ulang. Pilihan yang masih sesuai akan dipertahankan.",
              );
              return;
            }
            throw new Error(
              result.error?.message || "Perhitungan checkout gagal.",
            );
          }
          const data = result.data as CheckoutQuote;
          if (
            ![
              data.subtotal,
              data.shippingCost,
              data.discount,
              data.total,
            ].every((value) => Number.isSafeInteger(value) && value >= 0) ||
            data.total !== data.subtotal + data.shippingCost - data.discount
          ) {
            throw new Error("Ringkasan dari server tidak valid.");
          }
          if (active) {
            if (!rate) {
              const previous = wanted.current || rates[rateIdx];
              setRates(data.shippingRates);
              setRateContext(shippingKey);
              const index = previous
                ? data.shippingRates.findIndex(
                    (r) =>
                      r.courier === previous.courier &&
                      r.service === previous.service,
                  )
                : -1;
              if (
                index >= 0 &&
                data.shippingRates[index].cost === previous?.cost
              ) {
                setRateIdx(index);
              } else {
                setRateIdx(-1);
                if (previous)
                  setShippingNotice(
                    index >= 0
                      ? "Tarif layanan berubah. Pilih layanan untuk menyetujui ongkir terbaru."
                      : "Layanan sebelumnya tidak tersedia. Silakan pilih layanan lain.",
                  );
              }
              wanted.current = undefined;
            }
            setNow(Date.now());
            setQuote({ key: quoteKey, status: "ready", data });
          }
        } catch (error) {
          if (active && !controller.signal.aborted) {
            setQuote({
              key: quoteKey,
              status: "error",
              message:
                error instanceof Error ? error.message : "Koneksi terputus.",
            });
          }
        }
      },
      couponCode ? 350 : 0,
    );
    return () => {
      active = false;
      clearTimeout(timeout);
      controller.abort();
    };
    // quoteKey includes every request input; mutable object identities must not restart
    // in-flight quotes (selection preservation is covered by race regression tests).
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [quoteKey]);

  // Never render stale coupon/rate results, even before a previous request's effect cleanup runs.
  const currentQuote =
    quote?.key === quoteKey && quote.status === "ready" ? quote.data : null;
  useEffect(() => {
    if (!currentQuote?.quoteExpiresAt) return;
    const timer = setTimeout(
      () => setNow(Date.now()),
      Math.max(0, currentQuote.quoteExpiresAt - Date.now()) + 1,
    );
    return () => clearTimeout(timer);
  }, [currentQuote?.quoteExpiresAt]);
  const changedQuote =
    !!currentQuote &&
    !!rate &&
    (currentQuote.subtotal !== subtotal ||
      currentQuote.shippingCost !== rate?.cost);
  const expired =
    !!currentQuote?.quoteExpiresAt && now >= currentQuote.quoteExpiresAt;
  const addressValid = addressSchema.safeParse({
    ...location,
    recipientName: recipient,
    phone,
    line: street,
  }).success;
  const canSubmit =
    !!currentQuote?.shippingValid &&
    !changedQuote &&
    !expired &&
    addressValid &&
    !!bankId;
  function refreshShipping() {
    wanted.current = rate || rates[rateIdx];
    setRateContext("");
    setRetry((n) => n + 1);
  }

  return (
    <form
      action={action}
      className="checkout-form grid gap-6"
      data-testid="checkout-form"
      onSubmit={(event) => {
        if (submitting.current || !canSubmit) {
          event.preventDefault();
          return;
        }
        submitting.current = true;
      }}
    >
      <input type="hidden" name="intentId" value={intentId || ""} />
      <input type="hidden" name="requestId" value={requestId} />
      <input
        type="hidden"
        name="expectedLines"
        value={JSON.stringify(expectedLines)}
      />
      <input
        type="hidden"
        name="expectedQuote"
        value={
          currentQuote
            ? JSON.stringify({
                subtotal: currentQuote.subtotal,
                shippingCost: currentQuote.shippingCost,
                discount: currentQuote.discount,
                total: currentQuote.total,
              })
            : ""
        }
      />
      <div className="space-y-8">
        {/* Recipient and structured address; legacy text stays intact until confirmed. */}
        <section className="space-y-3">
          <h2 className="font-display text-lg font-bold text-ink">
            Data Penerima
          </h2>
          <div className="grid gap-3">
            <div>
              <Label htmlFor="checkout-recipient">Nama Penerima</Label>
              <Input
                name="recipientName"
                id="checkout-recipient"
                value={recipient}
                onChange={(e) => setRecipient(e.target.value)}
                minLength={2}
                maxLength={100}
                autoComplete="shipping name"
                placeholder="Nama lengkap penerima"
                required
                data-testid="input-recipient"
              />
            </div>
            <div>
              <Label htmlFor="checkout-phone">Nomor WhatsApp/HP</Label>
              <Input
                name="phone"
                id="checkout-phone"
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                autoComplete="shipping tel"
                placeholder="Contoh: 081234567890"
                required
                data-testid="input-phone"
              />
            </div>
          </div>
        </section>
        <section className="space-y-3">
          <h2 className="font-display text-lg font-bold text-ink">
            Alamat Pengiriman
          </h2>
          <RegionSelectorDialog
            jntCheckout={jntCheckout}
            value={location}
            onChange={(value) => {
              wanted.current = rate || rates[rateIdx];
              setLocation(value);
              setRateContext("");
            }}
          />
          {!location && address && (
            <p className="text-sm text-ink-soft">
              Alamat tersimpan: {address.city}, {address.province}. Lengkapi
              wilayah melalui Pilih Lokasi; detail jalan Anda tetap tersimpan.
            </p>
          )}
          {[
            "provinceCode",
            "cityCode",
            "districtCode",
            "villageCode",
            "province",
            "city",
            "village",
            "postalCode",
          ].map((name) => (
            <input
              key={name}
              type="hidden"
              name={name}
              value={location?.[name as keyof SelectedLocation] || ""}
            />
          ))}
          <div>
            <Label htmlFor="checkout-street">Detail alamat lengkap</Label>
            <Textarea
              name="line"
              id="checkout-street"
              value={street}
              onChange={(e) => setStreet(e.target.value)}
              minLength={4}
              maxLength={1000}
              autoComplete="shipping street-address"
              placeholder="Nama jalan, nomor rumah, RT/RW, dan patokan lokasi"
              required
              data-testid="input-line"
            />
          </div>
        </section>

        {/* Shipping */}
        <section className="space-y-3">
          <h2 className="flex items-center gap-2 font-display text-lg font-bold text-ink">
            <Truck size={18} /> Layanan Pengiriman
          </h2>
          {!location && (
            <p className="checkout-shipping-placeholder">
              <Truck size={22} aria-hidden="true" />{" "}
              {jntCheckout
                ? "Pilih lokasi untuk melihat ongkir J&T."
                : "Pilih lokasi untuk melihat ongkir."}
            </p>
          )}
          {location && !rates.length && quote?.status === "loading" && (
            <div
              role="status"
              aria-label="Memeriksa layanan pengiriman"
              className="grid min-h-20 gap-2"
              aria-busy="true"
            >
              <span className="sr-only">Memeriksa layanan pengiriman…</span>
              <div className="h-16 rounded-xl bg-zinc-100 motion-safe:animate-pulse" />
            </div>
          )}
          {rates.length > 0 && quote?.status === "loading" && (
            <p role="status" className="text-sm">
              {ratesValid ? "Memperbarui total…" : "Memvalidasi ulang layanan…"}
            </p>
          )}
          {shippingNotice && (
            <p role="status" className="text-sm">
              {shippingNotice}
            </p>
          )}
          {location && quote?.status === "error" && (
            <p role="alert" className="text-sm">
              {quote.message}{" "}
              <button
                type="button"
                onClick={refreshShipping}
                className="underline"
              >
                Coba lagi
              </button>
            </p>
          )}
          <div className="space-y-2" aria-busy={!!location && !ratesValid}>
            {rates.map((r, i) => (
              <label
                key={`${r.courier}:${r.service}`}
                className={cn(
                  "flex cursor-pointer items-center justify-between rounded-xl border p-3",
                  rateIdx === i ? "checkout-option-selected" : "border-line",
                )}
                data-testid={`ship-option-${i}`}
              >
                <div className="flex items-center gap-3">
                  <input
                    type="radio"
                    name="_rate"
                    checked={rateIdx === i}
                    disabled={!ratesValid}
                    onChange={() => {
                      setRateIdx(i);
                      setShippingNotice("");
                    }}
                    className="checkout-radio"
                  />
                  <div>
                    <p className="text-sm font-semibold text-ink">
                      {r.courier} - {r.service}
                    </p>
                    <p className="text-xs text-ink-muted">{r.etd}</p>
                    {r.mode === "manual" && (
                      <p className="text-xs text-ink-soft">
                        Ongkir flat per pesanan
                      </p>
                    )}
                  </div>
                </div>
                <span className="text-sm font-semibold">
                  {formatIDR(r.cost)}
                </span>
              </label>
            ))}
          </div>
          {location && currentQuote && rates.length === 0 && (
            <p role="status" className="text-sm text-ink-soft">
              Layanan pengiriman belum tersedia untuk alamat ini. Hubungi toko
              untuk tarif yang valid.
            </p>
          )}
          {rates.length > 0 && !rate && (
            <p className="text-sm text-ink-soft">
              Pilih layanan untuk memeriksa ongkir dan total terbaru.
            </p>
          )}
          <input type="hidden" name="courier" value={rate?.courier} />
          <input type="hidden" name="service" value={rate?.service} />
          <input type="hidden" name="shippingCost" value={rate?.cost ?? 0} />
          <input
            type="hidden"
            name="quoteToken"
            value={rate?.quoteToken || ""}
          />
        </section>

        {/* Payment */}
        <section className="space-y-3">
          <h2 className="flex items-center gap-2 font-display text-lg font-bold text-ink">
            <CreditCard size={18} /> Metode Pembayaran
          </h2>
          {banks.length === 0 && (
            <p role="alert" className="text-sm text-destructive">
              Metode pembayaran belum tersedia. Hubungi toko untuk melanjutkan.
            </p>
          )}
          <div className="space-y-2">
            {banks.map((b) => (
              <label
                key={b.id}
                className={cn(
                  "flex cursor-pointer items-center gap-3 rounded-xl border p-3",
                  bankId === b.id ? "checkout-option-selected" : "border-line",
                )}
                data-testid={`bank-option-${b.id}`}
              >
                <input
                  type="radio"
                  name="bankAccountId"
                  value={b.id}
                  checked={bankId === b.id}
                  onChange={() => setBankId(b.id)}
                  className="checkout-radio"
                  required
                />
                <div>
                  <p className="text-sm font-semibold text-ink">
                    {banks.length === 1
                      ? "Transfer Bank Manual"
                      : b.displayName}
                  </p>
                  <p className="text-xs text-ink-muted">
                    {banks.length === 1
                      ? "Konfirmasi setelah pesanan dibuat."
                      : b.bankName + " - a.n " + b.accountHolder}
                  </p>
                </div>
              </label>
            ))}
          </div>
        </section>

        <div>
          <Label htmlFor="checkout-coupon" className="checkout-coupon-title">
            <Ticket size={22} aria-hidden="true" /> Kode Kupon
          </Label>
          <input type="hidden" name="couponCode" value={couponCode} />
          <div className="checkout-coupon-controls">
            <Input
              id="checkout-coupon"
              value={couponDraft}
              maxLength={64}
              autoComplete="off"
              placeholder="Masukkan kode"
              data-testid="input-coupon"
              onChange={(event) =>
                setCouponDraft(
                  event.target.value.toUpperCase().replace(/\s/g, ""),
                )
              }
            />
            <Button
              type="button"
              variant="outline"
              onClick={() => setCouponCode(couponDraft)}
            >
              Terapkan
            </Button>
          </div>
          {currentQuote && couponCode && (
            <p
              className={cn(
                "mt-2 text-sm",
                currentQuote.couponCode ? "text-ink" : "text-destructive",
              )}
              role="status"
              data-testid="coupon-feedback"
            >
              {currentQuote.couponCode
                ? `Kupon ${currentQuote.couponCode} berhasil diterapkan.`
                : currentQuote.couponReason || "Kupon tidak valid."}
            </p>
          )}
        </div>
      </div>

      <div
        className="checkout-summary h-fit space-y-4 rounded-2xl border border-line p-5"
        data-testid="checkout-summary"
      >
        <h2 className="font-display text-lg font-bold text-ink">
          Ringkasan Pesanan
        </h2>
        <div className="space-y-2 text-sm">
          <div className="flex justify-between">
            <span className="text-ink-soft">Subtotal</span>
            <span className="font-semibold">
              {formatIDR(currentQuote?.subtotal ?? subtotal)}
            </span>
          </div>
          <div className="flex justify-between">
            <span className="text-ink-soft">
              Ongkir{rate ? ` (${rate.courier})` : ""}
            </span>
            <span className="font-semibold">
              {currentQuote?.shippingValid
                ? formatIDR(currentQuote.shippingCost)
                : "—"}
            </span>
          </div>
          {currentQuote && currentQuote.discount > 0 && (
            <div
              className="flex justify-between"
              data-testid="checkout-discount"
            >
              <span className="text-ink-soft">Diskon kupon</span>
              <span className="font-semibold">
                - {formatIDR(currentQuote.discount)}
              </span>
            </div>
          )}
        </div>
        <div className="flex justify-between border-t border-line pt-3">
          <span className="font-semibold text-ink">Total</span>
          <span
            className="font-display text-xl font-black text-ink"
            data-testid="checkout-total"
          >
            {currentQuote?.shippingValid ? formatIDR(currentQuote.total) : "—"}
          </span>
        </div>
        {location &&
          (!quote || quote.key !== quoteKey || quote.status === "loading") && (
            <p
              className="text-xs text-ink-soft"
              role="status"
              data-testid="checkout-quote-loading"
            >
              Memeriksa total terbaru…
            </p>
          )}
        {location && quote?.key === quoteKey && quote.status === "error" && (
          <div
            className="space-y-1 text-sm text-destructive"
            role="alert"
            data-testid="checkout-quote-error"
          >
            <p>{quote.message}</p>
            <span>Gunakan Coba lagi di layanan pengiriman.</span>
          </div>
        )}
        {changedQuote && (
          <p
            className="text-sm text-destructive"
            role="alert"
            data-testid="checkout-price-changed"
          >
            Harga atau ongkir berubah.{" "}
            <a
              href={
                intentId
                  ? `/checkout?intent=${encodeURIComponent(intentId)}`
                  : "/checkout"
              }
              className="font-semibold text-primary hover:text-blue-700 focus-visible:text-blue-700 active:text-blue-800"
            >
              Muat ulang checkout
            </a>{" "}
            untuk mengonfirmasi total terbaru.
          </p>
        )}
        {expired && (
          <p role="alert" className="text-sm">
            Ongkir kedaluwarsa.{" "}
            <button
              type="button"
              className="underline"
              onClick={refreshShipping}
            >
              Periksa ongkir kembali
            </button>
          </p>
        )}
        {(!addressValid || !rate) && (
          <p className="checkout-incomplete" role="status">
            <Info size={17} aria-hidden="true" /> Lengkapi alamat dan ongkir
            untuk melanjutkan.
          </p>
        )}
        {state?.ok === false && state?.error && (
          <p className="text-sm text-destructive" data-testid="checkout-error">
            {state.error}{" "}
            <a
              href={
                intentId
                  ? `/checkout?intent=${encodeURIComponent(intentId)}`
                  : "/checkout"
              }
              className="font-semibold text-primary hover:text-blue-700 focus-visible:text-blue-700 active:text-blue-800"
            >
              Muat ulang checkout untuk konfirmasi ulang
            </a>
          </p>
        )}
      </div>
      <div
        className="checkout-purchase-bar"
        role="group"
        aria-label="Konfirmasi pesanan"
        data-testid="checkout-purchase-bar"
      >
        <div
          className="checkout-sticky-total"
          aria-live="polite"
          aria-atomic="true"
        >
          <span className="text-xs">Total</span>
          <strong className="font-display" data-testid="checkout-sticky-total">
            {currentQuote?.shippingValid ? formatIDR(currentQuote.total) : "—"}
          </strong>
        </div>
        <PlaceOrderBtn disabled={!canSubmit} />
      </div>
    </form>
  );
}
