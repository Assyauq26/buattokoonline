"use client";

import { useEffect, useState, useRef, type FormEvent } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { SaveLabel, SettingsFeedback } from "./settings-feedback";
import Link from "next/link";
import {
  JntMappingSettings,
  readMapping,
  type MappingStatus,
} from "./jnt-mapping-settings";
import {
  shippingJson,
  shippingRequest,
  type ShippingStatus,
} from "./shipping-settings";

const integration = "/api/v1/admin/integrations/jnt";
const settings = "/api/v1/admin/shipping/settings";
const emptyEndpoints = {
  order: "",
  tariff: "",
  tracking: "",
  cancellation: "",
};
const emptyWarehouse = {
  name: "",
  contact: "",
  phone: "",
  address: "",
  districtCode: "",
};
const groups = [
  {
    kind: "order",
    label: "1. Order",
    fields: [
      ["orderKey", "Key"],
      ["orderUsername", "Username"],
      ["orderApiKey", "API Key"],
    ],
  },
  {
    kind: "tariff",
    label: "2. Tariff Check",
    fields: [
      ["tariffKey", "Key"],
      ["tariffCustomer", "Customer Name"],
    ],
  },
  {
    kind: "tracking",
    label: "3. Tracking",
    fields: [
      ["trackingUsername", "Username / e-company ID"],
      ["trackingPassword", "Password Track"],
    ],
  },
  {
    kind: "cancellation",
    label: "4. Cancellation",
    fields: [
      ["cancellationKey", "Key"],
      ["cancellationUsername", "Username"],
      ["cancellationApiKey", "API Key"],
    ],
  },
] as const;
type Endpoint = keyof typeof emptyEndpoints;
type Env = "sandbox" | "production";
type Stored = {
  configured: boolean;
  endpoints: typeof emptyEndpoints | null;
  sharedCancellation: boolean;
  credentialSet: Record<string, boolean>;
  seller: {
    warehouse: Omit<typeof emptyWarehouse, "districtCode"> & {
      districtCode?: string;
    };
    selectedServices?: string[];
    services: { verificationReference: string; validUntil: string }[];
  } | null;
};
const field =
  "mt-1 block min-h-11 w-full rounded-md border border-zinc-300 bg-white px-3 py-2 text-sm";

export function JntIntegrationSettings() {
  const params = useSearchParams();
  const [environment, setEnvironment] = useState<Env>(
    params.get("environment") === "production" ? "production" : "sandbox",
  );
  const [mapping, setMapping] = useState<MappingStatus | null>(null);
  return (
    <div className="space-y-5">
      <Link
        href="/admin/settings/shipping"
        className="text-sm font-semibold underline"
      >
        Pengiriman / API J&T Express
      </Link>
      <h1 className="font-display text-2xl font-bold">Integrasi J&T Express</h1>
      <p className="text-sm text-zinc-600">
        Hubungkan layanan J&T Express untuk pengiriman toko Anda.
      </p>
      <JntEnvironmentSettings
        key={environment}
        environment={environment}
        setEnvironment={setEnvironment}
        mapping={mapping}
        setMapping={setMapping}
      />
    </div>
  );
}

function JntEnvironmentSettings({
  environment,
  setEnvironment,
  mapping,
  setMapping,
}: {
  environment: Env;
  setEnvironment: (env: Env) => void;
  mapping: MappingStatus | null;
  setMapping: (value: MappingStatus) => void;
}) {
  const [endpoints, setEndpoints] = useState(emptyEndpoints);
  const [credentials, setCredentials] = useState<Record<string, string>>({});
  const [stored, setStored] = useState<Stored>();
  const [shipping, setShipping] = useState<ShippingStatus>();
  const [warehouse, setWarehouse] = useState(emptyWarehouse);
  const [sharedCancellation, setSharedCancellation] = useState(false);
  const [selectedServices, setSelectedServices] = useState<string[]>(["EZ"]);
  const [serviceReference, setServiceReference] = useState("");
  const [serviceExpiry, setServiceExpiry] = useState("");
  const [tests, setTests] = useState<Partial<Record<Endpoint, string>>>({});
  const [proof, setProof] = useState<string>();
  const [dirty, setDirty] = useState(false);
  const [enabled, setEnabled] = useState(false);
  const [busy, setBusy] = useState(true);
  const [notice, setNotice] = useState("");
  const lock = useRef(false),
    router = useRouter();
  const [operation, setOperation] = useState<"save" | "test" | null>(null);

  useEffect(() => {
    let alive = true;
    Promise.all([
      shippingRequest<Stored>(integration + "?environment=" + environment),
      shippingRequest<ShippingStatus>(settings + "?environment=" + environment),
      readMapping(),
    ])
      .then(([data, status, maps]) => {
        if (!alive) return;
        setStored(data);
        setShipping(status);
        setMapping(maps);
        setEnabled(status.activeEnvironment === environment);
        setEndpoints(
          data.endpoints ?? {
            order:
              (environment === "sandbox"
                ? "https://demo-ecommerce.inuat-jntexpress.id"
                : "https://api.jet.co.id") +
              "/jts-idn-ecommerce-api/api/order/create",
            cancellation:
              (environment === "sandbox"
                ? "https://demo-ecommerce.inuat-jntexpress.id"
                : "https://api.jet.co.id") +
              "/jts-idn-ecommerce-api/api/order/cancel",
            tariff:
              (environment === "sandbox"
                ? "https://demo-general.inuat-jntexpress.id"
                : "https://partner-track.jet.co.id") +
              "/jandt_track/inquiry.action",
            tracking:
              environment === "sandbox"
                ? "https://demo-general.inuat-jntexpress.id/jandt_track/track/trackAction!tracking.action"
                : "https://secure-jk.jet.co.id/jandt-order-web/track/trackAction!tracking.action",
          },
        );
        setSharedCancellation(data.configured && data.sharedCancellation);
        if (data.seller) {
          const { name, contact, phone, address, districtCode } =
            data.seller.warehouse;
          setWarehouse({
            name,
            contact,
            phone,
            address,
            districtCode: districtCode || "",
          });
          setSelectedServices(data.seller.selectedServices || ["EZ"]);
          setServiceReference(
            data.seller.services[0]?.verificationReference || "",
          );
          setServiceExpiry(
            data.seller.services[0]?.validUntil.slice(0, 10) || "",
          );
        }
      })
      .catch((error) => {
        if (alive) setNotice((error as Error).message);
      })
      .finally(() => {
        if (alive) setBusy(false);
      });
    return () => {
      alive = false;
    };
  }, [environment, setMapping]);

  function clearTests() {
    setTests({});
    setProof(undefined);
  }
  function edited() {
    setDirty(true);
    clearTests();
  }
  function draft() {
    return {
      environment,
      endpoints,
      credentials,
      sharedCancellation,
      seller: {
        warehouse: {
          ...warehouse,
          contact: warehouse.name,
          phone: warehouse.phone.replace(/^0/, "+62").replace(/^62/, "+62"),
        },
        selectedServices,
        services:
          serviceReference && serviceExpiry
            ? [
                {
                  code: "EZ",
                  verificationReference: serviceReference,
                  validUntil: new Date(
                    serviceExpiry + "T23:59:59.000Z",
                  ).toISOString(),
                },
              ]
            : [],
      },
    };
  }
  async function refresh() {
    setShipping(
      await shippingRequest<ShippingStatus>(
        settings + "?environment=" + environment,
      ),
    );
  }
  async function mappingChanged() {
    const maps = await readMapping();
    if (maps.activeVersion !== mapping?.activeVersion) {
      clearTests();
    }
    setMapping(maps);
    await refresh();
  }
  async function save(event: FormEvent) {
    event.preventDefault();
    if (lock.current || busy) return;
    lock.current = true;
    setOperation("save");
    setBusy(true);
    setNotice("");
    try {
      const data = await shippingRequest<Stored>(
        integration,
        shippingJson("PUT", { ...draft(), tariffProof: proof }),
      );
      setStored(data);
      setCredentials({});
      setDirty(false);
      setProof(undefined);
      if (enabled)
        await shippingRequest(
          settings,
          shippingJson("PUT", { method: "jnt", environment }),
        );
      else if (shipping?.activeEnvironment === environment) {
        if (shipping.manualFlat === null)
          throw new Error(
            "Konfigurasi tersimpan. Tetapkan tarif Manual sebelum menonaktifkan J&T.",
          );
        await shippingRequest(
          settings,
          shippingJson("PUT", { method: "manual", cost: shipping.manualFlat }),
        );
      }
      await refresh();
      setNotice("Konfigurasi tersimpan.");
      router.refresh();
    } catch (error) {
      setNotice((error as Error).message);
    } finally {
      lock.current = false;
      setOperation(null);
      setBusy(false);
    }
  }
  async function testAll() {
    if (lock.current || busy) return;
    lock.current = true;
    setOperation("test");
    setBusy(true);
    setNotice("");
    setTests({});
    try {
      const result = await shippingRequest<{
        message: string;
        results: { endpoint: Endpoint; message: string }[];
      }>(
        integration + "/test",
        shippingJson("POST", { draft: draft(), endpoint: "all" }),
      );
      setTests(
        Object.fromEntries(
          result.results.map((item) => [item.endpoint, item.message]),
        ),
      );
      setNotice(result.message);
    } catch (error) {
      setNotice((error as Error).message);
    } finally {
      lock.current = false;
      setOperation(null);
      setBusy(false);
    }
  }
  const card = "rounded-xl border border-zinc-200 bg-white p-5 shadow-sm";
  function credentialFields(group: (typeof groups)[number]) {
    return (
      <div className="space-y-2">
        {group.kind === "cancellation" && (
          <label className="flex gap-2 text-sm">
            <input
              type="checkbox"
              checked={sharedCancellation}
              onChange={(event) => {
                setSharedCancellation(event.target.checked);
                edited();
              }}
            />
            Gunakan kredensial Order
          </label>
        )}
        {(group.kind !== "cancellation" || !sharedCancellation) &&
          group.fields.map(([key, label]) => (
            <label
              key={key}
              className="grid items-center gap-2 text-sm sm:grid-cols-[120px_1fr]"
            >
              <span>{label}</span>
              <input
                aria-label={group.kind + " " + label}
                type="password"
                autoComplete="new-password"
                maxLength={300}
                className={field}
                placeholder={
                  stored?.credentialSet[key]
                    ? "Tersimpan"
                    : "Masukkan " + label.toLowerCase()
                }
                value={credentials[key] || ""}
                onChange={(event) => {
                  setCredentials((previous) => ({
                    ...previous,
                    [key]: event.target.value,
                  }));
                  edited();
                }}
              />
            </label>
          ))}
      </div>
    );
  }
  return (
    <form onSubmit={save} className="space-y-4">
      <section
        className={card + " flex flex-wrap items-center justify-between gap-4"}
      >
        <div>
          <div className="flex items-center gap-3">
            <span
              className={
                shipping?.activeEnvironment
                  ? "h-3 w-3 rounded-full bg-emerald-500"
                  : "h-3 w-3 rounded-full bg-amber-500"
              }
            />
            <strong>
              Status: {shipping?.activeEnvironment ? "Aktif" : "Belum aktif"}
            </strong>
            <button
              type="button"
              role="switch"
              aria-label="Aktifkan J&T Express"
              aria-checked={enabled}
              disabled={busy}
              onClick={() => {
                setEnabled((previous) => !previous);
                setDirty(true);
              }}
              className={
                "relative h-6 w-11 rounded-full disabled:opacity-50 " +
                (enabled ? "bg-primary" : "bg-zinc-300")
              }
            >
              <span
                className={
                  "absolute top-1 h-4 w-4 rounded-full bg-white transition-transform motion-reduce:transition-none " +
                  (enabled ? "left-1 translate-x-5" : "left-1")
                }
              />
            </button>
          </div>
          <p className="ml-6 mt-1 text-sm text-zinc-500">
            Checkout saat ini menggunakan{" "}
            {shipping?.activeEnvironment ? "J&T Express" : "Pengiriman Manual"}.
          </p>
        </div>
        <label className="w-full text-xs sm:w-56">
          Environment
          <select
            className={field}
            disabled={busy}
            value={environment}
            onChange={(event) => setEnvironment(event.target.value as Env)}
          >
            <option value="sandbox">Sandbox</option>
            <option value="production">Production</option>
          </select>
        </label>
      </section>
      <fieldset disabled={busy || !stored} className={card + " space-y-4"}>
        <div>
          <h2 className="text-lg font-bold">1. Kredensial API</h2>
          <p className="text-sm text-zinc-600">
            Masukkan kredensial API J&T sesuai dengan layanan yang digunakan.
            Field kosong mempertahankan kredensial yang sudah tersimpan.
          </p>
        </div>
        <div className="grid gap-4 lg:grid-cols-2">
          {groups.slice(0, 2).map((group) => (
            <section
              key={group.kind}
              className="rounded-lg border border-zinc-200 bg-zinc-50/60 p-4"
            >
              <h3 className="mb-4 border-l-4 border-current pl-3 font-semibold">
                {group.label.slice(3)}
              </h3>
              {credentialFields(group)}
            </section>
          ))}
        </div>
        {groups.slice(2).map((group) => (
          <details
            key={group.kind}
            className="rounded-lg border border-zinc-200 bg-zinc-50/60 p-3"
          >
            <summary className="cursor-pointer text-sm font-semibold">
              {group.label.slice(3)}
            </summary>
            <div className="pt-3">{credentialFields(group)}</div>
          </details>
        ))}
        <details>
          <summary className="cursor-pointer text-sm">
            Pengaturan endpoint lanjutan
          </summary>
          <div className="mt-3 grid gap-3 sm:grid-cols-2">
            {groups.map((group) => (
              <label key={group.kind} className="text-sm">
                {group.label.slice(3)}
                <input
                  type="url"
                  className={field}
                  maxLength={350}
                  value={endpoints[group.kind]}
                  onChange={(event) => {
                    setEndpoints((previous) => ({
                      ...previous,
                      [group.kind]: event.target.value,
                    }));
                    edited();
                  }}
                />
              </label>
            ))}
          </div>
        </details>
      </fieldset>
      <fieldset
        id="warehouse"
        disabled={busy || !stored}
        className={card + " space-y-4 scroll-mt-28"}
      >
        <div>
          <h2 className="text-lg font-bold">2. Gudang Pengirim</h2>
          <p className="text-sm text-zinc-600">
            Lengkapi alamat gudang untuk pengiriman toko Anda.
          </p>
        </div>
        <div className="grid gap-4 sm:grid-cols-2">
          <label className="text-sm">
            Nama
            <input
              required
              maxLength={30}
              className={field}
              value={warehouse.name}
              onChange={(event) => {
                setWarehouse((previous) => ({
                  ...previous,
                  name: event.target.value,
                }));
                edited();
              }}
            />
          </label>
          <label className="text-sm">
            Nomor HP
            <input
              required
              type="tel"
              maxLength={15}
              placeholder="081234567890"
              className={field}
              value={warehouse.phone}
              onChange={(event) => {
                setWarehouse((previous) => ({
                  ...previous,
                  phone: event.target.value,
                }));
                edited();
              }}
            />
          </label>
        </div>
        <WarehouseRegions
          mappingVersion={mapping?.activeVersion ?? null}
          value={warehouse.districtCode}
          onChange={(districtCode) => {
            setWarehouse((previous) => ({ ...previous, districtCode }));
            edited();
          }}
        />
        <label className="block text-sm">
          Alamat lengkap
          <textarea
            required
            maxLength={200}
            rows={2}
            className={field}
            value={warehouse.address}
            onChange={(event) => {
              setWarehouse((previous) => ({
                ...previous,
                address: event.target.value,
              }));
              edited();
            }}
          />
        </label>
      </fieldset>
      <fieldset disabled={busy || !stored}>
        <JntMappingSettings state={mapping} onChange={mappingChanged} />
      </fieldset>
      <fieldset disabled={busy || !stored} className={card + " space-y-3"}>
        <h2 className="text-lg font-bold">3. Pilihan Layanan</h2>
        <p className="text-sm text-zinc-600">
          Pilih layanan sesuai kontrak akun J&T Anda.
        </p>
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
          {["EZ", "HBO", "JND", "JSD"].map((code) => (
            <label
              key={code}
              className="flex cursor-pointer items-center gap-3 rounded-lg border border-zinc-200 p-4"
            >
              <input
                type="checkbox"
                checked={selectedServices.includes(code)}
                onChange={(event) => {
                  setSelectedServices((previous) =>
                    event.target.checked
                      ? [...previous, code]
                      : previous.filter((item) => item !== code),
                  );
                  edited();
                }}
                className="accent-current"
              />
              {code}
            </label>
          ))}
        </div>
      </fieldset>
      <fieldset disabled={busy || !stored} className={card + " space-y-3"}>
        <h2 className="text-lg font-bold">4. Uji Koneksi API</h2>
        <p className="text-sm text-zinc-600">
          Periksa respons HTTP seluruh endpoint tanpa membuat atau membatalkan
          pesanan. Respons HTTP 200 hanya membuktikan endpoint dapat dijangkau,
          bukan bukti kredensial, tarif, atau transaksi pengiriman valid.
        </p>
        <button
          type="button"
          onClick={testAll}
          className="min-h-11 rounded-lg bg-black px-5 text-sm font-semibold text-white disabled:opacity-50"
        >
          {operation === "test" ? "Memeriksa…" : "Test API"}
        </button>
        <div aria-live="polite" className="grid gap-2 text-sm sm:grid-cols-2">
          {groups.map((group) => (
            <p key={group.kind}>
              {group.label.slice(3)} · {tests[group.kind] || "Belum diuji"}
            </p>
          ))}
        </div>
      </fieldset>
      {dirty && (
        <p className="text-sm text-zinc-500">
          Perubahan diterapkan setelah Simpan Konfigurasi.
        </p>
      )}
      <SettingsFeedback message={notice} />
      <div className="flex justify-end">
        <button
          type="submit"
          disabled={busy || !stored}
          className="min-h-11 rounded-lg bg-black px-6 font-semibold text-white disabled:opacity-50"
        >
          <SaveLabel busy={operation === "save"}>Simpan Konfigurasi</SaveLabel>
        </button>
      </div>
    </form>
  );
}

function WarehouseRegions({
  value,
  onChange,
  mappingVersion,
}: {
  value: string;
  onChange: (code: string) => void;
  mappingVersion: string | null;
}) {
  const [province, setProvince] = useState("");
  const [city, setCity] = useState("");
  const [lists, setLists] = useState<
    Record<string, { code: string; name: string }[]>
  >({});
  const [error, setError] = useState("");
  useEffect(() => {
    if (!value || !mappingVersion) return;
    const controller = new AbortController();
    const params = new URLSearchParams({
      source: "jnt-warehouse",
      level: "provinces",
      selected: value,
    });
    shippingRequest<{ province: string; city: string }>(
      "/api/v1/regions?" + params,
      { signal: controller.signal },
    )
      .then((path) => {
        if (!controller.signal.aborted) {
          setProvince(path.province);
          setCity(path.city);
        }
      })
      .catch(() => {
        if (!controller.signal.aborted)
          setError("Pilih ulang gudang dari mapping J&T yang aktif.");
      });
    return () => controller.abort();
  }, [value, mappingVersion]);
  useEffect(() => {
    const controller = new AbortController();
    const requests = [
      ["provinces", ""],
      ...(province ? [["regencies", province]] : []),
      ...(city ? [["districts", city]] : []),
    ];
    Promise.all(
      requests.map(async ([level, parent]) => {
        const data = await shippingRequest<{
          data: { code: string; name: string }[];
        }>(
          "/api/v1/regions?" +
            new URLSearchParams({
              source: "jnt-warehouse",
              level,
              parent,
              province,
            }),
          { signal: controller.signal },
        );
        return [level, data.data] as const;
      }),
    )
      .then((items) => {
        setLists(Object.fromEntries(items));
        setError("");
      })
      .catch(() => {
        if (!controller.signal.aborted)
          setError("Wilayah gagal dimuat. Silakan muat ulang.");
      });
    return () => controller.abort();
  }, [province, city, mappingVersion]);
  return (
    <div className="grid gap-4 sm:grid-cols-3">
      <label className="text-sm">
        Provinsi
        <select
          aria-label="Provinsi"
          required
          className={field}
          value={province}
          onChange={(event) => {
            setProvince(event.target.value);
            setCity("");
            onChange("");
          }}
        >
          <option value="">Pilih provinsi</option>
          {lists.provinces?.map((row) => (
            <option key={row.code} value={row.code}>
              {row.name}
            </option>
          ))}
        </select>
      </label>
      <label className="text-sm">
        Kota/Kabupaten
        <select
          aria-label="Kota/Kabupaten"
          required
          disabled={!province}
          className={field}
          value={city}
          onChange={(event) => {
            setCity(event.target.value);
            onChange("");
          }}
        >
          <option value="">Pilih kota/kabupaten</option>
          {lists.regencies?.map((row) => (
            <option key={row.code} value={row.code}>
              {row.name}
            </option>
          ))}
        </select>
      </label>
      <label className="text-sm">
        Kecamatan
        <select
          aria-label="Kecamatan"
          required
          disabled={!city}
          className={field}
          value={value}
          onChange={(event) => onChange(event.target.value)}
        >
          <option value="">Pilih kecamatan</option>
          {lists.districts?.map((row) => (
            <option key={row.code} value={row.code}>
              {row.name}
            </option>
          ))}
        </select>
      </label>
      {!mappingVersion && (
        <p className="text-sm text-zinc-600">
          Unggah mapping J&T untuk mengisi pilihan wilayah gudang.
        </p>
      )}
      {error && (
        <p role="status" className="text-sm">
          {error}
        </p>
      )}
    </div>
  );
}
